from django.shortcuts import render,redirect
from django.contrib import messages
import json
import random
import requests
from datetime import datetime



# Create your views here.
def renderLogin(request):
    return render(request,"sign-in.html")

def renderPaciente(request):
    return render(request,"sing-upPaciente.html")

def renderDoctor(request):
    return render(request,"sing-upDoctor.html")

def renderEnfermera(request):
    return render(request,"sing-upEnfermera.html")

def renderPersonalAdmin(request):
    return render(request,"sing-upPersonalAdmin.html")

def renderRecursosHumanos(request):
    return render(request,"sing-upRecursosHumanos.html")

def renderEmpleado(request):
    return render(request,"sing-upEmpleado.html")

def registroHistoria(request):
     
    try:
        app_url="http://127.0.0.1:8080/HistoryQuery"
        print (request.GET)
        datos={"nombre":request.GET["name"],
            "Correo electronico":request.GET["Email Address"],
            "contraseña":request.GET["password"]
            }
        respuesta=requests.post(app_url, json=datos)
        response=json.loads(respuesta.text)
        if respuesta.status_code==200:
            id= random.randint(100, 99999)
            ses=Sesion(id=id, token=response["token"])
            ses.save()
            redireccion="/" + datos["rol"]+"/"+str(ses.id)
            return redirect(redireccion)
        else:
            raise Exception(str(response["message"]))    
    except Exception as error:
        #raise Exception(str(error))
        return render(requests,'error_template.html',{'error_message':str(error)}) 

