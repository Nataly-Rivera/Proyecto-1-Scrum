from django.apps import AppConfig


class ClinicafrontappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'clinicaFrontApp'
